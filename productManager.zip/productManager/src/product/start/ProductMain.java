package product.start;

import product.view.ProductView;

public class ProductMain {

	public static void main(String[] args) {
		ProductView pView = new ProductView();
	}
}

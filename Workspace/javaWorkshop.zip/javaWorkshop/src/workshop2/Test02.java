package workshop2;

public class Test02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int inx = 0;
//		 while(inx <= 6) {
//		 int jnx = 0;
//		 while( jnx <= inx) {
//		 System.out.print("*");
//		 jnx++;
//		 }
//		 System.out.print("@");
//		 inx++;
		for(int inx = 0 ;inx<=6; inx++ ){
			for(int jnx = 0;jnx<=inx;jnx++){
				System.out.println("*");
			}
		}
		 
	}

}
